public sealed class AdminOptions
{
    public IReadOnlyCollection<string> AdminUsers { get; init; } = Array.Empty<string>();
}