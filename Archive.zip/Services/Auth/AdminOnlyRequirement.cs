using Microsoft.AspNetCore.Authorization;

public sealed class AdminOnlyRequirement : IAuthorizationRequirement { }
